using System.Collections;
using UnityEngine;

public class Weapon : MonoBehaviour
{
    public Transform parentTransform;
}
